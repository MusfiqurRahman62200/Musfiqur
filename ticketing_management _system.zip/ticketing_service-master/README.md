# Ticketing Service
A basic framework for customer support ticketing system with secure signup/login for Users, Support Agents and Admins (To manage users/agents).

Use this to quick start your Customer Support System and develop to your taste as you move forward.
